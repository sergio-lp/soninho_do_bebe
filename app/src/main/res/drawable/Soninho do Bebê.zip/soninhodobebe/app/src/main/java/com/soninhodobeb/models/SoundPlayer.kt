package com.soninhodobeb.models

class SoundPlayer(var pos: Int, var id: String, var name: String, var volume: Int = 100)